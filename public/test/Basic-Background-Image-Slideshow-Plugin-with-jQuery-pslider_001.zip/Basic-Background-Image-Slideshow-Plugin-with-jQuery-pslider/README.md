# pslider
基于jquery可定制的渐入渐出轮播插件,使用非常简单
 
具体的使用请参照demo里面的代码



